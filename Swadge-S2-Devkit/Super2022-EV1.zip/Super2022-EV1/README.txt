Notes for this build:
 * White/Black
 * HASL
 * 131x96
 * Remove U2 from list

 * Confirm Parts Placement
 * Standard manufacture
 * Both Sides

 * Don't populate through-hole mic. (C233949)
 * Don't populate big caps. C28,C29,C3...
 * Use C3012328 for U5
 * This we are skipping the ESP32S2